# DFree
Hello World ! FREE Script Ddos HTTP! HTTP - HTTPS  #Command :) pkg install python3 pip3 install bs4 pip3 install pysocks  #Bye!  😁
CR : All3xJ
EDIT : Telzi 
